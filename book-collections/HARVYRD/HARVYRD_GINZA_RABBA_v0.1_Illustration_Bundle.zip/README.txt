HARVYRÐ · Ginza Rabba · Illustration bundle v0.1

Four original editorial illustrations, generated for this reader's guide.
The images are abstract and non-ritual: no sacred script, invented glyphs, manuscripts, or ceremonies are depicted.

Files:
- cover-art.jpg — cover illustration
- light-dark-cosmology.jpg — abstract light/dark cosmology
- transmission.jpg — abstract textual transmission
- river-memory.jpg — river landscape, no ritual scene

Palette: warm parchment, deep indigo, turquoise, violet, restrained gold.
